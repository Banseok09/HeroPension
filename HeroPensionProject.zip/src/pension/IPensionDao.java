package pension;

public interface IPensionDao {
	public PensionDto getChoicePension(int seq_pen);
}
