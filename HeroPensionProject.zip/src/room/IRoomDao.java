package room;

import java.util.List;

public interface IRoomDao {
	public List<RoomDto> getRoomList(int seq_pen); 
}
