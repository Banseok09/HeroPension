package roomIMG;

import java.util.List;

public interface IRoomImg {
	public List<RoomImgDto> getRoomImgList(int seq_room);
}
